message = 'tjwz wz tjq zqurqt pqzzagq'

# do not change the code above this line

# Write your algorithm to decode the message here:







# do not change the code below this line

print(message)